<?php


// https://www.php.net/manual/pt_BR/function.include.php
// include_once 'semana9inc.php';
// include_once 'semana9inc.php';
// O Once impede que o arquivo seja incluido NOVAMENTE
require 'semana9inc2.php';
require_once 'semana9inc2.php';





var_dump(eh_primo(233));


 ?>
