<?php

//https://www.php.net/manual/pt_BR/function.session-start

session_start();

var_dump($_SESSION);



 ?>
