<?php

//https://www.php.net/manual/pt_BR/function.session-start

session_start();

// $_SESSION['saudacao'] = "Ola eu sou o Yuri";


var_dump($_SESSION);



 ?>
